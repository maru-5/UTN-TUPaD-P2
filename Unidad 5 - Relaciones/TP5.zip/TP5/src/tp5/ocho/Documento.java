/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp5.ocho;
import java.util.Date;
/**
 *
 * @author marus
 */
public class Documento {
    private String titulo;
    private String contenido;
    private FirmaDigital firma; // composición

    public Documento(String titulo, String contenido, String codigoHash, Date fecha, Usuario usuario) {
        this.titulo = titulo;
        this.contenido = contenido;
        // composición: la firma se crea dentro del documento
        this.firma = new FirmaDigital(codigoHash, fecha, usuario);
    }
}

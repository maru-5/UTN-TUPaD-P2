/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp5;

/**
 *
 * @author marus
 */
import java.time.LocalDate;
import java.util.Date;
public class TP5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Titular titular = new Titular("Ana", 52457524);
        Pasaporte pasaporte = new Pasaporte("X123456", LocalDate.now(),"JPG", "blob");
        pasaporte.setTitular(titular);
        System.out.println( pasaporte.toString());
        */
        /*
        Celular celular = new Celular("unImei", "marca", "otroModelo");
        Usuario usuario = new Usuario("Ana", 42398);
        Bateria bateria = new Bateria("unModelo", 200);
        celular.setBateria(bateria);
        celular.setUsuario(usuario);
        System.out.println(celular.toString());
        */
        /*
        Autor autor = new Autor("Pepe", "argentino");
        Editorial editorial = new Editorial("unaEditorial", "direccionDeEditorial");
        Libro libro = new Libro("unLibro","codigoisbn" );
        libro.setAutor(autor);
        libro.setEditorial(editorial);
        System.out.println(libro.toString());
        */
        /*
        Banco banco = new Banco("Frnaces", "27-409762342-2");
        Cliente cliente = new Cliente("Pepe", 34564323);
        TarjetaDeCredito tarjeta = new TarjetaDeCredito("1258456987453256", "01/02/2038", banco);
        tarjeta.setCliente(cliente);
        System.out.println(tarjeta.toString());
        */
        /*
        Propietario propietario = new Propietario("Carlos", "8645312");
        Computadora computadora = new Computadora("unaMarca", "unaSerie", "unModelo", "unChipset");
        computadora.setPropietario(propietario);
        System.out.println(computadora.toString());
        */
        /*
        Cliente cliente = new Cliente("Lucia", "15848574");
        Mesa mesa = new Mesa(12, 4);
        Reserva reserva = new Reserva("2024-12-15", "20:30", cliente, mesa);
        System.out.println(reserva);
        */
        /*
        Motor motor = new Motor("unMotor", "MFhte7382");
        Vehiculo vehiculo = new Vehiculo("ABD123", "Ford", motor);
        Conductor conductor = new Conductor("Sofia", "273849fk");
        vehiculo.setConductor(conductor);
        */
        /*
        Usuario usuario = new Usuario("Maria", "maria@gmail.com");
        Documento documento = new Documento(
                "Contrato",
                "Este es un contrato.",
                "HASH462789352",
                new Date(),
                usuario
        );
        */
        /*
        Paciente paciente = new Paciente("Laura", "SWISS");
        Profesional profesional = new Profesional("Juan", "Cardiología");
        CitaMedica cita = new CitaMedica("2024-12-20", "15:30", paciente, profesional);
        */
        /*
        CuentaBancaria cuenta = new CuentaBancaria("1234567890123456789012", 25000.50,
                                                   "CLAVE123", new Date());
        Titular titular = new Titular("Ana", "45865895");
        cuenta.setTitular(titular);
        */
        /*
        Artista artista = new Artista("Gustavo Cerati", "Rock");
        Cancion cancion = new Cancion("Crimen", artista);
        Reproductor reproductor = new Reproductor();
        reproductor.reproducir(cancion);
        */
        /*
        Contribuyente contribuyente = new Contribuyente("Ana", "20-12345678-9");
        Impuesto impuesto = new Impuesto(15000.75, contribuyente);
        Calculadora calculadora = new Calculadora();
        calculadora.calcular(impuesto);
        */
        /*
        Usuario usuario = new Usuario("Carlos", "carlos@gmail.com");
        GeneradorQR generador = new GeneradorQR();
        CodigoQR qr = generador.generar("ruglhjzksdv", usuario);
        */
        /*
        Proyecto proyecto = new Proyecto("Corto", 15);
        EditorVideo editor = new EditorVideo();
        Render render = editor.exportar("MP4", proyecto);
        */
        
    }
    
}

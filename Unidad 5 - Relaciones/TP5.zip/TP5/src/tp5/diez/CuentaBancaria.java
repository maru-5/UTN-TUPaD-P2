/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp5.diez;
import java.util.Date;
/**
 *
 * @author marus
 */
public class CuentaBancaria {
    private String cbu;
    private double saldo;
    private ClaveSeguridad clave; // composición
    private Titular titular;      // asociación bidireccional

    public CuentaBancaria(String cbu, double saldo, String codigoClave, Date ultimaModificacion) {
        this.cbu = cbu;
        this.saldo = saldo;
        // composición: la clave siempre se crea con la cuenta
        this.clave = new ClaveSeguridad(codigoClave, ultimaModificacion);
    }

    public void setTitular(Titular titular) {
        this.titular = titular;
        if (titular.getCuenta() != this) {
            titular.setCuenta(this);
        }
    }

    public Titular getTitular() {
        return titular;
    }

    public String getCbu() {
        return cbu;
    }
}

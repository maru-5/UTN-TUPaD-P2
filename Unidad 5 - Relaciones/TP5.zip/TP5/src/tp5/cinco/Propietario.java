/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp5.cinco;

/**
 *
 * @author marus
 */
public class Propietario {
    private String nombre;
    private String dni;
    private Computadora computadora; 

    public Propietario(String nombre, String dni) {
        this.nombre = nombre;
        this.dni = dni;
    }
    public void setComputadora(Computadora computadora) {
        this.computadora = computadora;
        if (computadora.getPropietario() != this) {
            computadora.setPropietario(this);
        }
    }
    public Computadora getComputadora() {
        return computadora;
    }
    public String getDni() {
        return dni;
    }
}

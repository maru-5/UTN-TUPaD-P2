/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp5.trece;

/**
 *
 * @author marus
 */
public class GeneradorQR {
    public CodigoQR generar(String valor, Usuario usuario) {
        System.out.println("Generando código QR para " + usuario);
        return new CodigoQR(valor, usuario); // dependencia de creación
    }
}

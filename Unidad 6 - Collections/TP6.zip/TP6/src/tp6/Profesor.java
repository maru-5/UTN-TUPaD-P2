/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp6;

import java.util.ArrayList;

/**
 *
 * @author marus
 */
public class Profesor {
    private String id;
    private String nombre;
    private String especialidad;
    private ArrayList<Curso> cursos;

    public Profesor(String id, String nombre, String especialidad) {
        this.id = id;
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.cursos = new ArrayList<>();
    }
    public String getID(){
        return this.id;
    }
    public ArrayList<Curso> getCursos() {
        return cursos;
    }
    
    public ArrayList<Curso> getCursoss() {
        return this.cursos;
    }
    public String mostrarInfo(){
        
        return "Profesor: " + this.nombre + "\nId: "+ this.id + "\nEspecialidad: "+ this.especialidad + "\nCursos: "+ this.cursos.toString();
    }
    public void agregarCurso(Curso c){
        this.cursos.add(c);
    }
    public void eliminarCurso(Curso c){
        this.cursos.removeIf(curse -> curse.getCodigo().equalsIgnoreCase(c.getCodigo()));
    }
    public void listarCursos(){
        for(Curso c: cursos) {
            System.out.println(c);
        }
    }
    @Override
    public String toString() {
        return "Profesor{" + "id=" + id + ", nombre=" + nombre + ", especialidad=" + especialidad + '}';
    }
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Collectors;

/**
 *
 * @author marus
 */
public class Biblioteca {
    private String nombre;
    private ArrayList<Libro> libros;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.libros = new ArrayList<>();
    }
    
    public void agregarLibro(String isbn,int anioPublicacion, String titulo, Autor autor){
        Libro libro1 = new Libro(isbn,anioPublicacion, titulo, autor);
        this.libros.add(libro1);
    }
    
    public void listarLibros(){
        for(Libro l: libros){
            System.out.println(l.toString());
        }
    }
    
    public Libro buscarLibroPorIsbn(String isbn){
        Libro libroEncontrado = null;
        Iterator<Libro> it = this.libros.iterator();
        while(it.hasNext() && libroEncontrado == null){
            Libro l = it.next();
            if(l.getIsbn().equalsIgnoreCase(isbn)){
                libroEncontrado = l;
            }
        }
        return libroEncontrado;
    }
    
    public void eliminarLibro(String isbn){
        libros.removeIf(l -> l.getIsbn().equalsIgnoreCase(isbn));
    }
    
    public int obtenerCantidadLibros(){
        return libros.size();
    }
    public ArrayList<Libro> filtrarLibrosPorAnio(int anio){
        return libros.stream()
                .filter(l -> l.getAnio() == anio )
                .collect(Collectors.toCollection(ArrayList::new));
    }
    public ArrayList<Autor> mostrarAutoresDisponibles(){
        ArrayList<Autor> autores = new ArrayList<>();
        libros.forEach(l -> {
            if(! autores.contains(l.getAutor())){
                autores.add(l.getAutor());
            }
        });
        return autores;
    }
}

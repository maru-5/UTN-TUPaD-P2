/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp6;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.stream.Collectors;

/**
 *
 * @author marus
 */
public class Inventario {
    private ArrayList<Producto> productos;

    public Inventario() {
        this.productos = new ArrayList<Producto>() ;
    }
    
    public Producto buscarProductoPorId(String id){
        Producto prodEncontrado = null;
        Iterator<Producto> it = this.productos.iterator();
        while(it.hasNext() && prodEncontrado == null){
            Producto p = it.next();
            if(p.getID().equalsIgnoreCase(id)){
                prodEncontrado = p;
            }
        }
        return prodEncontrado;
    }
    
    public void agregarProducto(Producto p){
        if(buscarProductoPorId(p.getID()) == null){
            this.productos.add(p);
        }
    }
    
    public void listarProductos(){
        for (Producto p : productos){
            System.out.println(p);
        }
    }
    
    public void eliminarProducto(String id){
        productos.removeIf(p -> p.getID().equalsIgnoreCase(id));
    }
  
    public void actualizarStock(String id, int nuevaCantidad){
        Producto p = buscarProductoPorId(id);
        p.setStock(nuevaCantidad);
    }
    public ArrayList<Producto> filtrarPorCategoria(CategoriaProducto categoria){
        ArrayList<Producto> prodEncontrado = new ArrayList<>();
        for (Producto p : productos){
            if(p.getCategoria() == categoria){
                prodEncontrado.add(p);
            }
        }
        return prodEncontrado;
    }
    public int obtenerTotalStock(){
        return productos.stream().mapToInt(Producto::getStock).sum();
    }
    public int ontenerMayorStock(){
        return productos.stream().mapToInt(Producto::getStock).max().orElse(0);
    }
    public ArrayList<Producto> obtenerProductoConMayorStock(){
        int mayorStock = ontenerMayorStock();
        return productos.stream()
        .filter(p -> p.getStock() == mayorStock)
        .collect(Collectors.toCollection(ArrayList::new));
    }
    public ArrayList<Producto> filtrarProductosPorPrecio(double min, double max){
        return productos.stream()
                .filter(p -> p.getPrice() > min && p.getPrice() < max )
                .collect(Collectors.toCollection(ArrayList::new));
    }
    public ArrayList<CategoriaProducto> mostrarCategoriasDisponibles(){
        ArrayList<CategoriaProducto> categorias = new ArrayList<>();
        productos.forEach(p -> {
            if(! categorias.contains(p.getCategoria())){
                categorias.add(p.getCategoria());
            }
        });
        return categorias;
    }
}

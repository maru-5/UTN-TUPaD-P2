/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp6;

/**
 *
 * @author marus
 */
public class Curso {
    private String codigo;
    private String nombre;
    private Profesor profesor;

    public Curso(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }
    public String getCodigo(){
        return this.codigo;
    }
    public Profesor getProfesor(){
        return profesor;
    }
    public void setProfesor(Profesor p){        
        if (this.profesor != null) {
            this.profesor.getCursos().remove(this);
        }
        this.profesor = p;
        if (p != null && !p.getCursos().contains(this)) {
            p.getCursos().add(this);
        }
    }
    public void setSinProfesor(){
        this.profesor = null;
    }
    public String mostrarInfo(){
        String nombreProfesor = (this.profesor != null) ? this.profesor.toString() : "sin profesor";
        return "Curso: " + this.nombre + "\nCodigo: " + this.codigo + "\nProfesor: " + nombreProfesor;
    }
    @Override
    public String toString() {
        return "Curso{" + "codigo=" + codigo + ", nombre=" + nombre + '}';
    }
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp6;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author marus
 */
public class Universidad {
    private String nombre;
    private ArrayList<Profesor> profesores;
    private ArrayList<Curso> cursos;

    public Universidad(String nombre) {
        this.nombre = nombre;
        this.profesores = new ArrayList<>();
        this.cursos = new ArrayList<>();
    }
    
    public void agregarProfesor(Profesor p){
        this.profesores.add(p);
    }
    public void agregarCurso(Curso c){
        this.cursos.add(c);
    }
    public void asignarProfesorACurso(String codigoCurso, String idProfesor){
        Profesor p = buscarProfesorPorId(idProfesor);
        Curso c = buscarCursoPorCodigo(codigoCurso);
        c.setProfesor(p);         
    }
    public void listarProfesores(){
        for(Profesor p: profesores){
            System.out.println(p.mostrarInfo());
        }
    }
    public void listarCursos(){
        for(Curso c: cursos){
            System.out.println(c.mostrarInfo());
        }
    }
    public Profesor buscarProfesorPorId(String id){
        Profesor profeEncontrado = null;
        Iterator<Profesor> it = this.profesores.iterator();
        while(it.hasNext() && profeEncontrado == null){
            Profesor p = it.next();
            if(p.getID().equalsIgnoreCase(id)){
                profeEncontrado = p;
            }
        }
        return profeEncontrado;
    }
    public Curso buscarCursoPorCodigo(String codigo){
        Curso cursoEncontrado = null;
        Iterator<Curso> it = this.cursos.iterator();
        while(it.hasNext() && cursoEncontrado == null){
            Curso p = it.next();
            if(p.getCodigo().equalsIgnoreCase(codigo)){
                cursoEncontrado = p;
            }
        }
        return cursoEncontrado;
    }
    public void eliminarCurso(String codigo){
        Curso c = buscarCursoPorCodigo(codigo);
        Profesor p = c.getProfesor();
        p.eliminarCurso(c);
        cursos.remove(c);
    }
    public void eliminarProfesor(String id) {
        Profesor p = buscarProfesorPorId(id);
        ArrayList<Curso> cursosDelProfesor = new ArrayList<>(p.getCursos());
        for (Curso c : cursosDelProfesor) {
            c.setProfesor(null); 
        }
        profesores.remove(p);
    }
    public void cursosPorProfesor(){
        profesores.forEach(p -> System.out.println(
                "Profesor: " + p.getID() + ", cantidad de cursos: " + p.getCursos().size()
        ));
    }
}

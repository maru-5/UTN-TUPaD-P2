/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication6;

import java.util.ArrayList;

/**
 *
 * @author marus
 */
public class JavaApplication6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // 1
        Auto a = new Auto("a", "b", 3);
        System.out.println(a.toString());
        //2
        Circulo f1 = new Circulo("Circulo",5.0);
        Rectangulo f2 = new Rectangulo("Rectangulo",5.0, 3.0);
        System.out.println("Area circulo: " + f1.calcularArea());
        System.out.println("Area rectangulo: " + f2.calcularArea());
        //3
        ArrayList<Empleado> empleados = new ArrayList<>();
        empleados.add(new EmpleadoPlanta(4));
        empleados.add(new EmpleadoTemporal());     
        empleados.forEach(emp -> {
            if( emp instanceof EmpleadoPlanta){
                System.out.println("Sueldo Planta: " + emp.calcularSueldo(50.2, 20.3));
            } else if ( emp instanceof EmpleadoTemporal){
                System.out.println("Sueldo Temporal: " + emp.calcularSueldo(50.2, 20.3));
            }
        });
        //4
        ArrayList<Animal> animales = new ArrayList<>();
        animales.add(new Gato());
        animales.add(new Perro());
        animales.add(new Vaca());
        animales.forEach(anim -> System.out.println(anim.hacerSonido()));
    }
    
}

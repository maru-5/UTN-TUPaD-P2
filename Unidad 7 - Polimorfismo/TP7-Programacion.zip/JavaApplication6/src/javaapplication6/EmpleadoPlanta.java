/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication6;

/**
 *
 * @author marus
 */
public class EmpleadoPlanta extends Empleado{
    private int antiguedad; 

    public EmpleadoPlanta(int antiguedad) {
        this.antiguedad = antiguedad;
    }
    
    @Override
    public double calcularSueldo(double horas, double valorHora) {
       return horas * valorHora * antiguedad;
    }

    
}

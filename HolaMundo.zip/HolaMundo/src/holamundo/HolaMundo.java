/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package holamundo;
import java.util.Scanner;

/**
 *
 * @author marus
 */
public class HolaMundo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingresa el primer num: ");
        int num1 = sc.nextInt();
        System.out.print("Ingresa el segundo num: ");
        int num2 = sc.nextInt();

        System.out.print("Division con nros enteros");
        int resultado = num1 / num2; 
        System.out.println("Resultado: " + resultado);
        
        System.out.print("Ingresa el primer num decimal: ");
        double numDec1 = sc.nextInt();
        System.out.print("Ingresa el segundo num decimal: ");
        double numDec2 = sc.nextInt();
        System.out.print("Division con nros decimales");
        double resultado2 = numDec1 / numDec2; 
        System.out.println("Resultado2: " + resultado2);
        
        
        
        
        sc.close();   
    }
    
}
